import datetime , time
import os.path
from bot_flight import get_next_six
from common_funtions import get_file_name, get_flight_dates, get_flight_data, get_json_fire, get_after_week, update_fire, get_flight_data
import json
import time
from time import sleep
import datetime
import os
from selenium import webdriver
from common_funtions import *


# city1 = 'JFK'
# city2 = "MIA"
def info_cities(city1, city2, driver):
    file_name, reason = get_next_six(city1, city2, driver)
    if file_name == 'True':
        return reason
    out_list = []
    print(out_list)
    # file_name = 'data/JFK-MIA-2020-11-02a.csv'

    with open(file_name, 'r') as f:
        file = f.read().split('\n')
        for each_row in file:
            if each_row == '':
                break
            row_data = {'date': each_row.split(',')[0], 'price': int(each_row.split(',')[1][1:])}
            out_list.append(row_data)
            print(row_data)
        sorted_temp = sorted(out_list, key=lambda k: k['price'])
        print(sorted_temp)
        sum = 0
        # print(sorted_temp)
        for t in sorted_temp:
            sum = sum + t['price']
        average = sum / len(sorted_temp)

        with open(file_name.replace('.csv', '.json'), 'w+') as j:
            tmp = dict()
            tmp['lowest'] = json.loads(str(sorted_temp[0]).replace("'", '"'))
            tmp['average'] = int(average)
            json.dump(tmp, fp=j)

    # check if file exist

    '''get old file name'''

    old_date = datetime.datetime.today().date() - datetime.timedelta(days=1)
    old_json_file_name = get_file_name(city1, city2, old_date) + '.json'
    # print(old_json_file_name)
    # then compare average current with yesterday
    curr_json_file_name = file_name.replace('.csv', '.json')
    # print(curr_json_file_name,old_json_file_name)
    with open(curr_json_file_name, 'r') as f:
        cur_data = json.loads(f.read())

    if not os.path.isfile(old_json_file_name):
        # print('closing... no previous data found')
        temp_price_15 = cur_data['average'] - ((cur_data['average'] / 100) * 15)
        flight_info = get_flight_data(city1, city2, cur_data['lowest']['date'], driver)
        f = open("url.txt", "r+")
        burl = f.read()
        f.truncate(0)
        f.close()
        print("d1")
        data_set = get_json_fire()
        with open('cities.json', 'r') as f:
            cities_symbol = json.loads(f.read())
        data_set['price'] = str(cur_data['lowest']['price'])
        data_set['departure_airport'] = cities_symbol[city1]
        data_set['destination_airport'] = cities_symbol[city2]
        data_set['airline'] = flight_info
        data_set['available_dates'] = get_flight_dates(sorted_temp, cur_data['lowest']['price'])
        data_set['booking_url'] = burl
        data_set['timestamp'] = str(time.mktime(datetime.datetime.now().timetuple()) * 1000)
        # new object
        data_set['background_city_image'] = 'city_background/' + cities_symbol[city2] + '.png'
        try:
            data_set['image_url'] = 'airline_images/' + flight_info + '.png'
        except:
            data_set['image_url'] = 'airline_images/' + 'default' + '.png'
        # print(city1,city2)
        update_fire(city1, city2, data_set)
        return data_set

    with open(old_json_file_name, 'r') as f:
        old_data = json.loads(f.read())

    temp_price_15 = cur_data['average'] - ((cur_data['average'] / 100) * 15)
    # print('print',temp_price_15, cur_data['lowest']['price'])

    if not cur_data['lowest']['price'] < old_data['lowest']['price']:
        return 'None'

    # CHECK if price is lower then sent to firebase else nothing to worry about
    if cur_data['lowest']['price'] < temp_price_15:
        # print('send to firebase')
        # get flight data for this date curr_data['lowest']+7days
        flight_info = get_flight_data(city1, city2, cur_data['lowest']['date'], driver)
        # print(flight_info)
        data_set = get_json_fire()

        # data structure
        with open('cities.json', 'r') as f:
            cities_symbol = json.loads(f.read())

        data_set['price'] = str(cur_data['lowest']['price'])
        data_set['departure_airport'] = cities_symbol[city1]
        data_set['destination_airport'] = cities_symbol[city2]
        data_set['airline'] = flight_info
        data_set['available_dates'] = get_flight_dates(sorted_temp, cur_data['lowest']['price'])
        data_set['booking_url'] = burl
        data_set['timestamp'] = str(time.mktime(datetime.datetime.now().timetuple()) * 1000)
        # new object
        data_set['background_city_image'] = 'city_background/' + cities_symbol[city2] + '.png'
        try:
            data_set['image_url'] = 'airline_images/' + flight_info + '.png'
        except:
            data_set['image_url'] = 'airline_images/' + 'default' + '.png'
        # print(city1,city2)
        update_fire(city1, city2, data_set)
        print("Data sent to Fb")

        return data_set
