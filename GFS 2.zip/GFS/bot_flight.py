from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.keys import Keys
import time
from time import sleep
import datetime
import os
from selenium import webdriver


def get_next_six(city1, city2, driver):
    if not os.path.exists('data'):
        os.makedirs('data')
    curr_date = datetime.datetime.today().date()
    after_week = curr_date + datetime.timedelta(days=7)
    out_file_name = 'data/' + str(city1 + '-' + city2) + '-' + str(curr_date) + '.csv'
    out_file = open(out_file_name, 'w+')
    driver.get('https://www.google.com/travel/flights')
    time.sleep(2)
    Dep = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input")
    Dep.click()
    print("click")
    time.sleep(2)
    print("wait")
    dep1 = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[6]/div[2]/div[2]/div[1]/div/input")
    dep1.send_keys(city1)
    dep1.send_keys(Keys.RETURN)
    arv = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[4]/div/div/div[1]/div/div/input")
    arv.click()
    arv1 = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[6]/div[2]/div[2]/div[1]/div/input")
    arv1.send_keys(city2)
    arv1.send_keys(Keys.RETURN)
    curr_date = datetime.datetime.today().date()
    print(curr_date)

    after_week = curr_date + datetime.timedelta(days=7)

    print(after_week)
    crd = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div/div[1]/div/input")
    crd.click()
    time.sleep(2)
    crd1 = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div/input")
    #crd1.send_keys(Keys.BACKSPACE)
    time.sleep(4)
    crd1.send_keys(str(curr_date))
    afd = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/input")
    afd.send_keys(Keys.BACKSPACE)
    afd.send_keys(str(after_week))
    b = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/div/div[3]/div[3]/div/button")
    b.click()
    print("B1")

  
    

    try:
        check_restriction = WebDriverWait(driver, 10).until(ec.visibility_of_element_located((By.XPATH,
                                                                                              "/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[2]/div/div[2]/div[3]/div/div/div/div/div[2]/div[1]]")))

        # print(check_restriction.text)
        if check_restriction.text == 'Travel restricted':
            return 'True', 'Travel Restricted'
    except:
        check_restriction = 'open'

    # /html/body/div[2]/div[2]/div/div[2]/div[3]/div/jsl/div/div[2]/main[4]/div[6]/div[2]/div/p[2]/span[1]

    try:
        check_snap = WebDriverWait(driver, 5).until(ec.visibility_of_element_located((By.XPATH,
                                                                                      "/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[2]/div/div[2]/div[8]/div/div/p[1]")))
        # print('snap',check_snap.text)
        if 'Aw snap' in str(check_snap.text):
            return 'True', 'Aw snap'
    except:
        check_snap = 'open'

    try:

        # works for best departing flights heading
        check_departing = WebDriverWait(driver, 10).until(ec.visibility_of_element_located((By.XPATH,

                                                                                            '/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[2]/div/div[2]/div[4]/div/div[1]/div/div[1]/h3')))

    except:
        print('no heading')
        check_departing = 'open'
        return 'True', 'no heading'

    # wait for menu item to appear, then click it
    # /html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div/div[1]/div
    try:
        flight_menu = WebDriverWait(driver, 10).until(ec.visibility_of_element_located((By.XPATH,

                                                                                        "/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[1]/div/div/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div/div[1]/div/input")))
        flight_menu.click()
        print("c1")
        sleep(5)
    except:
        return 'True', 'calender error' + str(driver.current_url)

    # wait for price to appear
    def click_for_next_month(driver):
        tk = 0
        print("C2")
        while True:
            try:
                next_month = WebDriverWait(driver, 10).until(ec.visibility_of_element_located((By.XPATH,
                                                                                               "/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[1]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[3]/div/button")))
                next_month.click()
                print("c4")
                return
            except:
                tk = tk + 1
                print("C5")
            if tk > 100:
                return 'missing error'

    # document.getElementsByClassName('gws-travel-calendar__annotation')

    # /html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[3]/div/button
    # /html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div/div[

    # check price capture link
    # /html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div/div[2]/div[3]/div[1]/div[3]/div/div[2]
    def get_price_list_text(driver):
        z_list = []
        print("C6")
        for x in range(1, 8):

            try:
                try:
                    y_list = driver.find_element_by_xpath(
                        '''/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[1]/div/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div/div[''' + str(x) + ''']/div[3]''')
                    price_temp_y = str(y_list.text).split('\n')
                    # print(y_list.text)
                except:
                    continue

                for t in price_temp_y:
                    try:
                        if int(t) < 32:
                            continue
                        else:
                            z_list.append(t)
                    except:
                        z_list.append(t)
            except:
                return z_list

        return z_list

    try:
        driver.find_element_by_xpath(
            '/html/body/sc-survey-survey-manager/div/div[4]/sc-shared-material-button/button/span/sc-shared-material-icon/div').click()
    except:
        pass

    prices_list = []
    for x in range(4):
        if x == 0:
            sleep(4)

        if x == 3:
            list_price_per_page = get_price_list_text(driver)
            # print(list_price_per_page)
            for tmp in list_price_per_page:
                if tmp == '????':
                    continue
                prices_list.append(str(tmp).replace(',', '').replace('K', '000').replace('.', ''))
            continue
        click_for_next_month(driver)
        sleep(4)
        click_for_next_month(driver)
        sleep(4)

    c = 0
    for each_price in prices_list:
        if each_price == '':
            c = c + 1
            # print('skip', each_price)
            continue
        # print(each_price)
        # print('\n%%%%%%%%%%%%%%%%%%\n')

        write_date = str(curr_date + datetime.timedelta(days=c))
        out_file.write(str(write_date) + ',' +
                       each_price
                       + '\n'
                       )
        c = c + 1
    print("f1")
    return out_file_name, 'Worked fine'


#driver = webdriver.Firefox(executable_path="geckodriver")
#
# print(get_next_six("NYC", "DCA", driver))
