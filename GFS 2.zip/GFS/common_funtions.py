import datetime
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as ec
import time
from time import sleep
global burl





def get_file_name(city1, city2, curr_date):
    return 'data/' + str(city1 + '-' + city2) + '-' + str(curr_date)


def get_flight_dates(tmp_list, price, ):
    tmp_dates = []
    for x in tmp_list:
        t = dict(x)
        if t['price'] == price:
            tmp_dates.append(t['date'])
        else:
            break
            print("crash")
    return tmp_dates


def get_after_week(tardate):
    tardate = datetime.datetime.strptime(tardate, '%Y-%m-%d').date()
    after_week = tardate + datetime.timedelta(days=7)
    return after_week


url_up = 'https://raw.githubusercontent.com/EhtishamSabir/token/master/unfare'


def get_flight_data(city1, city2, tar_date, driver):
    
    print("E0")
    tar_date = datetime.datetime.strptime(tar_date, '%Y-%m-%d').date()
    after_week = tar_date + datetime.timedelta(days=7)

    driver.get('https://www.google.com/travel/flights')
    time.sleep(2)
    Dep = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input")
    Dep.click()
    print("click")
    time.sleep(2)
    print("wait")
    dep1 = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[6]/div[2]/div[2]/div[1]/div/input")
    dep1.send_keys(city1)
    dep1.send_keys(Keys.RETURN)
    arv = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[4]/div/div/div[1]/div/div/input")
    arv.click()
    arv1 = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[1]/div[6]/div[2]/div[2]/div[1]/div/input")
    arv1.send_keys(city2)
    arv1.send_keys(Keys.RETURN)
    curr_date = datetime.datetime.today().date()
    print("TARGET")
    print(curr_date)

    print(after_week)
    crd = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div/div[1]/div/input")
    crd.click()
    time.sleep(2)
    crd1 = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/div/input")
    crd1.send_keys(Keys.BACKSPACE)
    crd1.send_keys(str(tar_date))
    afd = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/input")
    afd.send_keys(Keys.BACKSPACE)
    afd.send_keys(str(after_week))
    b = driver.find_element_by_xpath("/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/div[2]/div[1]/div[1]/div[2]/div[2]/div/div/div[2]/div/div[3]/div[3]/div/button")
    b.click()
    burl = driver.current_url
    print(burl)
    print("E1")
    f = open("url.txt", "w")
    f.write(burl)
   
    
    #driver.get('https://www.google.com/flights?hl=en#flt=' + city1 + '.' + city2 + '.' + str(
        #tar_date) + '*' + city2 + '.' + city1 + '.' + str(after_week) + ';c:USD;e:1;sd:1;t:f')
    try:
        flight_info = WebDriverWait(driver, 10).until(ec.visibility_of_element_located((By.XPATH,
                                                                                    "/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[2]/div/div[2]/div[4]/div/div[2]/div/div[1]/div/div[1]/div[2]/div[2]/div[2]/div[2]")))
        flight_info=str(flight_info.text)
        best = True
    except:
        try:
            flight_info = WebDriverWait(driver, 5).until(ec.visibility_of_element_located((By.XPATH,
                                                                                       "/html/body/c-wiz[2]/div/div[2]/div/c-wiz/div/c-wiz/c-wiz/div[2]/div[2]/div/div[2]/div[6]/div/div[2]/div/div[1]/div/div[1]/div[2]/div[2]/div[2]/div[2]")))
            flight_info = str(flight_info.text)
        except:
            return 'multiple-airlines'
        best = False

    #print('False  ',flight_info)
    flight_info = str(flight_info).split('\n')

    if best:
        #print(flight_info[2])
        return flight_info[0]
    else:
        return flight_info[0]




def get_json_fire():
    sec = datetime.datetime.today().second

    j_data = {
        "departure_airport": "New York",
        "destination_airport": "Miami",
        "flight_class": "false",
        "airline": "virgin",
        "timestamp": "20/09/2020, 19.30",
        "price": "250",
        "round_trip": "true",
        "premium_deal": "false",
        "image_url": "",
        "background_city_image":"",
        "available_dates": [
            "2020-10-20 13:04:42 +0000",
            "2020-10-29 13:04:42 +0000",
            "2020-10-25 13:04:42 +0000",

        ],
        "Notes": "Make sure to check for baggage rules and covid restrictions.",
        "booking_url": "https://www.google.com/flights?hl=en#flt=(DEPARTURE CODE).(ARIVAL CODE).2020-11-15 (DATE)"
    }
    if sec < 33:
        prem = "true"
    else:
        prem = "false"
    j_data['premium_deal'] = prem

    return j_data


def firebase_init():
    # Fetch the service account key JSON file contents
    cred = credentials.Certificate('creds.json')

    # Initialize the app with a service account, granting admin privileges
    firebase_admin.initialize_app(cred, {
        'databaseURL': 'https://unfare-af356.firebaseio.com/'
    })
    print('firebase ready')


def validity():
    return ""


def update_fire(city1, city2, data):
    print("sending start")
    # As an admin, the app has access to read and write all data, regradless of Security Rules
    ref = db.reference('deals/' + city1 + '-' + city2)
    # Add a new doc in collection 'cities' with ID 'LA'
    print(ref.set(data))
    print("data sent")

