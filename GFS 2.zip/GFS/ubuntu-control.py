from city_grab import info_cities
import datetime
from common_funtions import firebase_init
from selenium import webdriver
from concurrent.futures import ThreadPoolExecutor
from time import sleep
from multiprocessing import Process
import os


resp = {'pair': '', 'response': ''}
response_list = []


def get_pair_list():
    print('A')
    f = open('combined.csv', 'r', encoding="utf-8")
    pair_list = f.read().split('\n')
    f.close()
    return pair_list


def pair_range():
    print('b')
    pair_range = []
    for x in range(0, 21463, 1460):
        if x == 0:
            continue
        if x == 1460:
            pair_range.append(str(x - 1460) + ',' + str(x))
        else:
            pair_range.append(str(x - 1459) + ',' + str(x))
    pair_range.append('20441,21462')
    return pair_range


def work_from_to(tmp):
    print('c')
    firebase_init()
    print('D')
    if tmp == '':
        return

    A = int(tmp.split(',')[0])
    B = int(tmp.split(',')[1])
    options = webdriver.FirefoxOptions()
    options.add_argument("--headless")
    options.set_preference('permissions.default.image', 2)
    while True:
        try:
            driver = webdriver.Firefox(options=options, executable_path=os.getcwd() + '/drivers/geckodriver')
            print('Worked')
            break
        except:
            print('could not get')
            sleep(60 * 20)
    # sleep(300)
    driver.get('https://www.google.com/flights')

    pair_list = get_pair_list()[A:B]
    # print(pair_list)
    # print('start', datetime.datetime.today())
    for pair in pair_list:
        if pair == '':
            continue
        pair = pair.split(',')
        print(info_cities(pair[0], pair[1], driver))
        t = info_cities(pair[0], pair[1], driver)
        try:
            print(t)
        except:
            print(pair, 'Error')
            pass
        # print('process',datetime.datetime.today())
    # print('end', datetime.datetime.today())
    driver.quit()


if __name__ == '__main__':
    print('U- started', datetime.datetime.today())
    temp_list = pair_range()
    # print(temp_list,len(temp_list))
    list_process = []
    while True:
        for x in range(15):
            p = Process(target=work_from_to, args=(temp_list[x],))
            list_process.append(p)
            p.start()
            sleep(60 * 20)
        print("Completed", datetime.datetime.today())
        sleep(60 * 60 * 120)

        for proc in list_process:
            try:
                proc.close()
            except:
                continue
        list_process.clear()
